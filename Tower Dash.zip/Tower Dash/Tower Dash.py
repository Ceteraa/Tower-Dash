import pygame
import sys
import os.path
import math

from pygame.locals import *

# Screen information
SCREEN_WIDTH = 960
SCREEN_HEIGHT = 720
FPS = 30
currentFrame = 0
totalFrames = 0
FramePerSec = pygame.time.Clock()
# Player movement physics
vec = pygame.math.Vector2
p1_ACC = 1.2
p1_FRIC = -0.13
p2_ACC = 1.2
p2_FRIC = -0.13
jumpStr = -14.5

# Defined colors
BLUE  = (0, 0, 255)
RED   = (255, 0, 0)
GREEN = (0, 255, 0)
PURPLE = (128, 0, 128)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Initialize pygame, create window
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Tower Dash")
clock = pygame.time.Clock()

# Player variables / assets
inGame = False
inCutscene = False
cutsceneScroll = True
inMenu = True
points = 0
score = 0
font = pygame.font.Font((os.path.join('Assets', '8514oem.fon')), 72)

p1_controls = pygame.image.load(os.path.join('Assets', 'p1-controls.png')).convert_alpha()
p1_controls = pygame.transform.scale(p1_controls, (960, 280))
p1_controls.set_alpha(0)
p1_displayControls = True

p2_controls = pygame.image.load(os.path.join('Assets', 'p2-controls.png')).convert_alpha()
p2_controls = pygame.transform.scale(p2_controls, (960, 280))
p2_controls.set_alpha(0)
p2_displayControls = True

p1_heart = pygame.image.load(os.path.join('Assets', 'p1-heart.png')).convert_alpha()
p1_heart = pygame.transform.scale(p1_heart, (54, 54))
p2_heart = pygame.image.load(os.path.join('Assets', 'p2-heart.png')).convert_alpha()
p2_heart = pygame.transform.scale(p2_heart, (54, 54))

# -- Player1
p1_hitbox = pygame.image.load(os.path.join('Assets', 'p1-HITBOX-full.png')).convert_alpha()
p1_hitbox_ducked = pygame.transform.scale(p1_hitbox, (32, 16))
p1_texture_top = pygame.image.load(os.path.join('Assets', 'p1-top.png')).convert_alpha()
p1_texture_bottom = pygame.image.load(os.path.join('Assets', 'p1-bottom.png')).convert_alpha()
p1_texture_eyes = pygame.image.load(os.path.join('Assets', 'p1-eyes.png')).convert_alpha()
p1_faceLeft = pygame.transform.flip(p1_texture_eyes, True, False)
p1_facing = p1_texture_eyes
p1_startPOS = (246, 604)
p1_duckAnim = 0
p1_lives = 3
p1_isHurt = False
p1_hurtFrame = 0
p1_isAlive = True
# -- Player2
p2_hitbox = pygame.image.load(os.path.join('Assets', 'p2-HITBOX-full.png')).convert_alpha()
p2_hitbox_ducked = pygame.transform.scale(p2_hitbox, (32, 16))
p2_texture_top = pygame.image.load(os.path.join('Assets', 'p2-top.png')).convert_alpha()
p2_texture_bottom = pygame.image.load(os.path.join('Assets', 'p2-bottom.png')).convert_alpha()
p2_texture_eyes = pygame.image.load(os.path.join('Assets', 'p2-eyes.png')).convert_alpha()
p2_faceRight = pygame.transform.flip(p2_texture_eyes, True, False)
p2_facing = p2_texture_eyes
p2_startPOS = (716, 604)
p2_duckAnim = 0
p2_lives = 3
p2_isHurt = False
p2_hurtFrame = 0
p2_isAlive = True

# Tells which assets to display on screen (testing purposes)
# -- Player1
p1_blitHitbox = False
p1_blitBottom = True
p1_blitTop = True
p1_blitEyes = True
# -- Player2
p2_blitHitbox = False
p2_blitBottom = True
p2_blitTop = True
p2_blitEyes = True

# Entity class
class Entity(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

# Player1 class
class Player1(pygame.sprite.Sprite):
    # Player1 init function
    def __init__(self):
        super().__init__()
        self.image = p1_hitbox
        self.rect = self.image.get_rect()
        self.pos = vec(p1_startPOS)
        self.vel = vec(0,0)
        self.acc = vec(0,0)

    # Player1 movement function
    def move(self):

        self.acc = vec(0, 0.85)   # change y-value for gravity strength
        if self.isFinished == False:
            pressed_keys = pygame.key.get_pressed()
            global p1_facing

            if pressed_keys[K_a]:
                p1_facing = p1_faceLeft
                self.acc.x = -p1_ACC
            if pressed_keys[K_d]:
                p1_facing = p1_texture_eyes
                self.acc.x = p1_ACC
            
            self.acc.x += self.vel.x * p1_FRIC
            self.vel += self.acc
            self.pos += self.vel + 0.5 * self.acc

            # Prevent Player1 from going past the edges of the game screen
            if self.pos.x > (SCREEN_WIDTH - 138):
                self.pos.x = (SCREEN_WIDTH - 138)
            if self.pos.x < 138:
                self.pos.x = 138

        global p1_centerX
        global p1_centerY
        global p1_blitX
        global p1_blitY
        p1_centerX = self.pos.x
        p1_centerY = self.pos.y - 18
        p1_blitX = self.pos.x - 18
        p1_blitY = self.pos.y - 36
    
    # Player1 duck function
    def duck(self):
        # Variables
        global p1_topPOS
        global p1_eyePOS
        global p1_topPOS_ducked
        global p1_eyePOS_ducked
        global p1_duckAnim
        global p1_hitbox_POSy
        p1_topPOS = p1_centerY - 18
        p1_eyePOS = p1_centerY - 18
        p1_topPOS_ducked = p1_centerY - 2
        p1_eyePOS_ducked = p1_centerY - 4
        p1_hitbox_POSy = self.pos.y
        self.isDucked = False

        # Detect if pressing S key
        if self.isFinished == False:
            pressed_keys = pygame.key.get_pressed()
            if pressed_keys[K_s]:
                self.isDucked = True
                self.image = p1_hitbox_ducked   # resize hitbox
                p1_hitbox_POSy = self.pos.y + 16
                if p1_duckAnim < 4:   # determine next ducking animation frame
                    p1_duckAnim = p1_duckAnim + 1
            else:
                self.isDucked = False
                self.image = p1_hitbox
                if p1_duckAnim > 0:
                    p1_duckAnim = p1_duckAnim - 1

        # Find position of Player1 eyes and top based on animation frame
        if p1_duckAnim == 4:
            p1_topPOS = p1_topPOS_ducked
            p1_eyePOS = p1_eyePOS_ducked
        elif p1_duckAnim == 0:
            p1_topPOS = p1_centerY - 18
            p1_eyePOS = p1_centerY - 18
        else:
            p1_topPOS = p1_centerY + (p1_duckAnim * 4) - 18
            p1_eyePOS = p1_centerY + (p1_duckAnim * 4) - 18

    # Player1 collisions function
    def collisions(self):
        self.newPosX = self.pos.x
        self.newPosY = self.pos.y
        self.newVelX = self.vel.x
        self.newVelY = self.vel.y
        global p1_platCol
        global p1_wallCol
        global p1_blockCol
        global p1_halfCol
        global playersFinished
        self.isOnGround = False

        self.finishCol = pygame.sprite.spritecollide(self, finish1s, False)
        if self.finishCol:
            if self.isFinished == False:
                playersFinished += 1
            self.isFinished = True

        # Player1 moving in y direction
        if self.vel.y > 0:   # Player1 moving down
            p1_platCol = pygame.sprite.spritecollide(self, platforms, False)   # Identify all platforms touching Player1
            if p1_platCol:
                if self.rect.top < p1_platCol[0].rect.top:
                    self.newPosY = p1_platCol[0].rect.top + 1
                    self.newVelY = 0
                    if self.pos.x > p1_platCol[0].rect.left and self.pos.x < p1_platCol[0].rect.right:
                        self.isOnGround = True
            p1_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player1
            if p1_blockCol:
                self.distToCenter0_x = abs(p1_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p1_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x < self.distToCenter0_y:   # if Player1 touching block on top/bottom
                    if self.rect.top < p1_blockCol[0].rect.top:
                        self.newPosY = p1_blockCol[0].rect.top + 1
                        self.newVelY = 0
                        if self.pos.x > p1_blockCol[0].rect.left and self.pos.x < p1_blockCol[0].rect.right:
                            self.isOnGround = True
            p1_halfCol = pygame.sprite.spritecollide(self, halfplats, False)   # Identify all half-platforms touching Player1
            if p1_halfCol:
                if self.rect.top < p1_halfCol[0].rect.top:
                    self.newPosY = p1_halfCol[0].rect.top + 1
                    self.newVelY = 0  
                    if self.pos.x > p1_halfCol[0].rect.left and self.pos.x < p1_halfCol[0].rect.right:
                        self.isOnGround = True  
        if self.vel.y < 0:   # Player1 moving up
            p1_platCol = pygame.sprite.spritecollide(self, platforms, False)   # Identify all platforms touching Player1
            if p1_platCol:
                if self.rect.top > p1_platCol[0].rect.top:
                    self.newPosY = p1_platCol[0].rect.bottom + 35
                    self.newVelY = 0
            p1_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player1
            if p1_blockCol:
                self.distToCenter0_x = abs(p1_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p1_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x < self.distToCenter0_y:   # if Player1 touching block on top/bottom
                    if self.rect.top > p1_blockCol[0].rect.top:
                        self.newPosY = p1_blockCol[0].rect.bottom + 35
                        self.newVelY = 0
        # Player1 moving in x direction
        if self.vel.x > 0:   # Player1 moving right
            p1_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player1
            if p1_blockCol:
                self.distToCenter0_x = abs(p1_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p1_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x >= self.distToCenter0_y:   # if Player1 touching block on sides
                    if self.rect.right < p1_blockCol[0].rect.right:   # if Player1 right is inside block
                        self.newPosX = p1_blockCol[0].rect.left - 17
                        self.newVelX = 0
            p1_wallCol = pygame.sprite.spritecollide(self, walls, False)   # Identify all walls touching Player1
            if p1_wallCol:
                if self.rect.right < p1_wallCol[0].rect.right:
                    self.newPosX = p1_wallCol[0].rect.left - 17
                    self.newVelX = 0
        if self.vel.x < 0:   # Player1 moving left
            p1_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player1
            if p1_blockCol:
                self.distToCenter0_x = abs(p1_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p1_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x >= self.distToCenter0_y:   # if Player1 touching block on sides
                    if self.rect.left > p1_blockCol[0].rect.left:   # if Player1 left is inside block
                        self.newPosX = p1_blockCol[0].rect.right + 17
                        self.newVelX = 0
            p1_wallCol = pygame.sprite.spritecollide(self, walls, False)   # Identify all walls touching Player1
            if p1_wallCol:
                if self.rect.left > p1_wallCol[0].rect.left:
                    self.newPosX = p1_wallCol[0].rect.right + 17
                    self.newVelX = 0

        if self.isOnGround == True:
            if self.newPosY < 720:
                self.safeX = self.newPosX
                self.safeY = self.newPosY

        # Teleport Player1 to last safe position if falls off screen
        if self.pos.y > 755:
            self.isOnGround = False
            self.newPosX = self.safeX
            self.newPosY = self.safeY
            self.newVelX = 0
            self.newVelY = 0

        # Update Player1 position and velocity
        self.pos.x = self.newPosX
        self.pos.y = self.newPosY
        self.vel.x = self.newVelX
        self.vel.y = self.newVelY

    # Player1 jump function
    def jump(self):
        if self.isFinished == False:
            p1_platCol = pygame.sprite.spritecollide(self, platforms, False)
            if p1_platCol:
                if self.pos.y == p1_platCol[0].rect.top + 1:
                    self.vel.y = jumpStr
            p1_blockCol = pygame.sprite.spritecollide(self, blocks, False)
            if p1_blockCol:
                if self.pos.y == p1_blockCol[0].rect.top + 1:
                    self.vel.y = jumpStr
            p1_halfCol = pygame.sprite.spritecollide(self, halfplats, False)
            if p1_halfCol:
                if self.pos.y == p1_halfCol[0].rect.top + 1:
                    self.vel.y = jumpStr
            p1_jumpCol = pygame.sprite.spritecollide(self, jumppads, False)
            if p1_jumpCol:
                self.vel.y = jumpStr
        
    # Player1 point scoring function
    def pointUpdate(self):
        global p1_smallScore
        global p1_bigScore
        global points
        
        p1_smallScore = pygame.sprite.spritecollide(self, smallcoins, False)
        if p1_smallScore:
            points += 1
            smallcoins.remove(p1_smallScore[0])
            allGameplay.remove(p1_smallScore[0])
        
        p1_bigScore = pygame.sprite.spritecollide(self, bigcoins, False)
        if p1_bigScore:
            points += 25
            bigcoins.remove(p1_bigScore[0])
            allGameplay.remove(p1_bigScore[0])

    # Player1 damage function
    def damage(self):
            global p1_spikeCol
            global p1_isHurt
            global p1_lives
            global p1_hurtFrame
            global p1_isAlive
            global playersFinished
            p1_spikeCol = pygame.sprite.spritecollide(self, spikes, False)
            if p1_isHurt == False:
                if p1_spikeCol:
                    p1_isHurt = True
                    p1_lives -= 1
                    p1_hurtFrame = totalFrames
            if p1_lives < 1:
                p1_isAlive = False
                self.isFinished = True
                playersFinished += 1
            if totalFrames == p1_hurtFrame + 60:
                p1_isHurt = False

    # Player1 blit function
    def blit(self):
        self.rect.midbottom = (p1_centerX, p1_hitbox_POSy)   # updates hitbox
        if p1_isHurt == False or (totalFrames % 8 > 4):
            if p1_blitBottom == True:
                screen.blit(p1_texture_bottom, (p1_blitX, p1_blitY))
            if p1_blitTop == True:
                screen.blit(p1_texture_top, (p1_blitX, p1_topPOS))
            if p1_blitEyes == True:
                screen.blit(p1_facing, (p1_blitX, p1_eyePOS))


# Player2 class
class Player2(pygame.sprite.Sprite):
    # Player2 init function
    def __init__(self):
        super().__init__()
        self.image = p2_hitbox
        self.rect = self.image.get_rect()
        self.pos = vec(p2_startPOS)
        self.vel = vec(0,0)
        self.acc = vec(0,0)

    # Player2 movement function
    def move(self):
        
        self.acc = vec(0, 0.85)   # change y-value for gravity strength
        if self.isFinished == False:
            pressed_keys = pygame.key.get_pressed()
            global p2_facing

            if pressed_keys[K_l]:
                p2_facing = p2_faceRight
                self.acc.x = p2_ACC
            if pressed_keys[K_j]:
                p2_facing = p2_texture_eyes
                self.acc.x = -p2_ACC
            
            self.acc.x += self.vel.x * p2_FRIC
            self.vel += self.acc
            self.pos += self.vel + 0.5 * self.acc

            # Prevent Player2 from going past the edges of the game screen
            if self.pos.x > (SCREEN_WIDTH - 138):
                self.pos.x = (SCREEN_WIDTH - 138)
            if self.pos.x < 138:
                self.pos.x = 138

        global p2_centerX
        global p2_centerY
        global p2_blitX
        global p2_blitY
        p2_centerX = self.pos.x
        p2_centerY = self.pos.y - 18
        p2_blitX = self.pos.x - 18
        p2_blitY = self.pos.y - 36
    
    # Player2 duck function
    def duck(self):
        # Variables
        global p2_topPOS
        global p2_eyePOS
        global p2_topPOS_ducked
        global p2_eyePOS_ducked
        global p2_duckAnim
        global p2_hitbox_POSy
        p2_topPOS = p2_centerY - 18
        p2_eyePOS = p2_centerY - 18
        p2_topPOS_ducked = p2_centerY - 2
        p2_eyePOS_ducked = p2_centerY - 4
        p2_hitbox_POSy = self.pos.y

        # Detect if pressing K key
        if self.isFinished == False:
            pressed_keys = pygame.key.get_pressed()
            if pressed_keys[K_k]:
                self.image = p2_hitbox_ducked   # resize hitbox
                p2_hitbox_POSy = self.pos.y + 16
                if p2_duckAnim < 4:   # determine next ducking animation frame
                    p2_duckAnim = p2_duckAnim + 1
            else:
                self.image = p2_hitbox
                if p2_duckAnim > 0:
                    p2_duckAnim = p2_duckAnim - 1

        # Find position of Player2 eyes and top based on animation frame
        if p2_duckAnim == 4:
            p2_topPOS = p2_topPOS_ducked
            p2_eyePOS = p2_eyePOS_ducked
        elif p2_duckAnim == 0:
            p2_topPOS = p2_centerY - 18
            p2_eyePOS = p2_centerY - 18
        else:
            p2_topPOS = p2_centerY + (p2_duckAnim * 4) - 18
            p2_eyePOS = p2_centerY + (p2_duckAnim * 4) - 18

    # Player2 collisions function
    def collisions(self):
        self.newPosX = self.pos.x
        self.newPosY = self.pos.y
        self.newVelX = self.vel.x
        self.newVelY = self.vel.y
        global p2_platCol
        global p2_wallCol
        global p2_blockCol
        global p2_halfCol
        global playersFinished
        self.isOnGround = False

        self.finishCol = pygame.sprite.spritecollide(self, finish2s, False)
        if self.finishCol:
            if self.isFinished == False:
                playersFinished += 1
            self.isFinished = True

        # Player2 moving in y direction
        if self.vel.y > 0:   # Player2 moving down
            p2_platCol = pygame.sprite.spritecollide(self, platforms, False)   # Identify all platforms touching Player2
            if p2_platCol:
                if self.rect.top < p2_platCol[0].rect.top:
                    self.newPosY = p2_platCol[0].rect.top + 1
                    self.newVelY = 0
                    if self.pos.x > p2_platCol[0].rect.left and self.pos.x < p2_platCol[0].rect.right:
                        self.isOnGround = True
            p2_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player2
            if p2_blockCol:
                self.distToCenter0_x = abs(p2_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p2_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x < self.distToCenter0_y:   # if Player2 touching block on top/bottom
                    if self.rect.top < p2_blockCol[0].rect.top:
                        self.newPosY = p2_blockCol[0].rect.top + 1
                        self.newVelY = 0
                        if self.pos.x > p2_blockCol[0].rect.left and self.pos.x < p2_blockCol[0].rect.right:
                            self.isOnGround = True
            p2_halfCol = pygame.sprite.spritecollide(self, halfplats, False)   # Identify all half-platforms touching Player2
            if p2_halfCol:
                if self.rect.top < p2_halfCol[0].rect.top:
                    self.newPosY = p2_halfCol[0].rect.top + 1
                    self.newVelY = 0    
                    if self.pos.x > p2_halfCol[0].rect.left and self.pos.x < p2_halfCol[0].rect.right:
                        self.isOnGround = True       
        if self.vel.y < 0:   # Player2 moving up
            p2_platCol = pygame.sprite.spritecollide(self, platforms, False)   # Identify all platforms touching Player2
            if p2_platCol:
                if self.rect.top > p2_platCol[0].rect.top:
                    self.newPosY = p2_platCol[0].rect.bottom + 35
                    self.newVelY = 0
            p2_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player2
            if p2_blockCol:
                self.distToCenter0_x = abs(p2_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p2_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x < self.distToCenter0_y:   # if Player2 touching block on top/bottom
                    if self.rect.top > p2_blockCol[0].rect.top:
                        self.newPosY = p2_blockCol[0].rect.bottom + 35
                        self.newVelY = 0
        # Player2 moving in x direction
        if self.vel.x > 0:   # Player2 moving right
            p2_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player2
            if p2_blockCol:
                self.distToCenter0_x = abs(p2_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p2_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x >= self.distToCenter0_y:   # if Player2 touching block on sides
                    if self.rect.right < p2_blockCol[0].rect.right:   # if Player2 right is inside block
                        self.newPosX = p2_blockCol[0].rect.left - 17
                        self.newVelX = 0
            p2_wallCol = pygame.sprite.spritecollide(self, walls, False)   # Identify all walls touching Player2
            if p2_wallCol:
                if self.rect.right < p2_wallCol[0].rect.right:
                    self.newPosX = p2_wallCol[0].rect.left - 17
                    self.newVelX = 0
        if self.vel.x < 0:   # Player2 moving left
            p2_blockCol = pygame.sprite.spritecollide(self, blocks, False)   # Identify all blocks touching Player2
            if p2_blockCol:
                self.distToCenter0_x = abs(p2_blockCol[0].center_x - self.pos.x)
                self.distToCenter0_y = abs(p2_blockCol[0].center_y - (self.pos.y - 18))
                if self.distToCenter0_x >= self.distToCenter0_y:   # if Player2 touching block on sides
                    if self.rect.left > p2_blockCol[0].rect.left:   # if Player2 left is inside block
                        self.newPosX = p2_blockCol[0].rect.right + 17
                        self.newVelX = 0
            p2_wallCol = pygame.sprite.spritecollide(self, walls, False)   # Identify all walls touching Player2
            if p2_wallCol:
                if self.rect.left > p2_wallCol[0].rect.left:
                    self.newPosX = p2_wallCol[0].rect.right + 17
                    self.newVelX = 0

        if self.isOnGround == True:
            if self.newPosY < 720:
                self.safeX = self.newPosX
                self.safeY = self.newPosY

        # Teleport Player2 to last safe position if falls off screen
        if self.pos.y > 755:
            self.isOnGround = False
            self.newPosX = self.safeX
            self.newPosY = self.safeY
            self.newVelX = 0
            self.newVelY = 0

        # Update Player2 position and velocity
        self.pos.x = self.newPosX
        self.pos.y = self.newPosY
        self.vel.x = self.newVelX
        self.vel.y = self.newVelY

    # Player2 jump function
    def jump(self):
        if self.isFinished == False:
            p2_platCol = pygame.sprite.spritecollide(self, platforms, False)
            if p2_platCol:
                if self.pos.y == p2_platCol[0].rect.top + 1:
                    self.vel.y = jumpStr
            p2_blockCol = pygame.sprite.spritecollide(self, blocks, False)
            if p2_blockCol:
                if self.pos.y == p2_blockCol[0].rect.top + 1:
                    self.vel.y = jumpStr
            p2_halfCol = pygame.sprite.spritecollide(self, halfplats, False)
            if p2_halfCol:
                if self.pos.y == p2_halfCol[0].rect.top + 1:
                    self.vel.y = jumpStr
            p2_jumpCol = pygame.sprite.spritecollide(self, jumppads, False)
            if p2_jumpCol:
                self.vel.y = jumpStr

    # Player2 point scoring function
    def pointUpdate(self):
        global p2_smallScore
        global p2_bigScore
        global points

        p2_smallScore = pygame.sprite.spritecollide(self, smallcoins, False)
        if p2_smallScore:
            points += 1
            smallcoins.remove(p2_smallScore[0])
            allGameplay.remove(p2_smallScore[0])
        
        p2_bigScore = pygame.sprite.spritecollide(self, bigcoins, False)
        if p2_bigScore:
            points += 25
            bigcoins.remove(p2_bigScore[0])
            allGameplay.remove(p2_bigScore[0])

    # Player2 damage function
    def damage(self):
            global p2_spikeCol
            global p2_isHurt
            global p2_lives
            global p2_hurtFrame
            global p2_isAlive
            global playersFinished
            p2_spikeCol = pygame.sprite.spritecollide(self, spikes, False)
            if p2_isHurt == False:
                if p2_spikeCol:
                    p2_isHurt = True
                    p2_lives -= 1
                    p2_hurtFrame = totalFrames
            if p2_lives < 1:
                p2_isAlive = False
                self.isFinished = True
                playersFinished += 1
            if totalFrames == p2_hurtFrame + 60:
                p2_isHurt = False

    # Player2 blit function
    def blit(self):
        self.rect.midbottom = (p2_centerX, p2_hitbox_POSy)   # updates hitbox
        if p2_isHurt == False or (totalFrames % 8 > 4):
            if p2_blitBottom == True:
                screen.blit(p2_texture_bottom, (p2_blitX, p2_blitY))
            if p2_blitTop == True:
                screen.blit(p2_texture_top, (p2_blitX, p2_topPOS))
            if p2_blitEyes == True:
                screen.blit(p2_facing, (p2_blitX, p2_eyePOS))

# Scroll gameplay, despawn all objects that leave screen
def gpScroll():
    global scrolled
    global avgHeight
    avgHeight = (p1_centerY + p2_centerY) / 2   # average height between the 2 players
    if playersFinished < 2:
        if avgHeight < 300:
            if scrolled < 3672:
                bgScroll()
                scrolled += 4
                for i in allGameplay:
                    i.rect.y += 4
                for i in spikeups:
                    i.rectY += 4
                for i in spikedowns:
                    i.rectY += 4
                for i in finish1s:
                    i.rectY += 4
                for i in finish2s:
                    i.rectY += 4
                if p1_isAlive == True:
                    P1.pos.y += 4
                    P1.rect.bottom = P1.pos.y
                if p2_isAlive == True:
                    P2.pos.y += 4
                    P2.rect.bottom = P2.pos.y
    for i in platforms:
        if i.rect.y > SCREEN_HEIGHT:
            platforms.remove(i)
    for i in walls:
        if i.rect.y > SCREEN_HEIGHT:
            walls.remove(i)
    for i in blocks:
        if i.rect.y > SCREEN_HEIGHT:
            blocks.remove(i)
    for i in halfplats:
        if i.rect.y > SCREEN_HEIGHT:
            halfplats.remove(i)
    for i in jumppads:
        if i.rect.y > SCREEN_HEIGHT:
            jumppads.remove(i)
    for i in spikes:
        if i.rect.y > SCREEN_HEIGHT:
            spikes.remove(i)
    for i in smallcoins:
        if i.rect.y > SCREEN_HEIGHT:
            smallcoins.remove(i)
    for i in bigcoins:
        if i.rect.y > SCREEN_HEIGHT:
            bigcoins.remove(i)
            
# Scroll background/walls
def bgScroll():
    global allowScroll
    global bg_scroll
    global walls_scroll
    if allowScroll == True:
        bg_scroll += 2
        if bg_scroll > 720:
            bg_scroll = 0
        walls_scroll += 4
        if walls_scroll > 720:
            walls_scroll = 0

# --- Gameplay classes ---
gp_alpha = 0
# Platform class
class platform(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.Surface((36, 36))
        self.surf.fill(PURPLE)
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x, y, 36, 36)
# Wall class
class wall(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.Surface((36, 36))
        self.surf.fill(PURPLE)
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x, y, 36, 36)
# Block class
class block(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.Surface((36, 36))
        self.surf.fill(PURPLE)
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x, y, 36, 36)
        self.center_x = self.rect.left + 18
        self.center_y = self.rect.top + 18
# Half-platform class
class halfplat(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.Surface((36, 18))
        self.surf.fill(PURPLE)
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x, y, 36, 18)
# Jump-pad class
class jumppad(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.image.load(os.path.join('Assets', 'jumppad.png')).convert_alpha()
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x, y, 36, 36)
# Up-facing spike class
class spikeup(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.image = pygame.image.load(os.path.join('Assets', 'spike-up.png')).convert_alpha()
        self.image.set_alpha(gp_alpha)
        self.surf = pygame.Surface((0, 0))
        self.surf.set_alpha(gp_alpha)
        self.rectX = x
        self.rectY = y
        self.rect = Rect(x + 9, y + 22, 18, 14)
# Down-facing spike class
class spikedown(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.image = pygame.image.load(os.path.join('Assets', 'spike-down.png')).convert_alpha()
        self.image.set_alpha(gp_alpha)
        self.surf = pygame.Surface((0, 0))
        self.surf.set_alpha(gp_alpha)
        self.rectX = x
        self.rectY = y
        self.rect = Rect(x + 9, y, 18, 14)
# Small coin class
class smallcoin(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.image.load(os.path.join('Assets', 'coin-small.png')).convert_alpha()
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x + 8, y + 8, 20, 20)
# Big coin class
class bigcoin(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.surf = pygame.image.load(os.path.join('Assets', 'coin-big.png')).convert_alpha()
        self.surf.set_alpha(gp_alpha)
        self.rect = Rect(x + 4, y + 4, 28, 28)
# Player1 finish point class
class finish1(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.image = pygame.image.load(os.path.join('Assets', 'p1-endflag.png')).convert_alpha()
        self.image.set_alpha(gp_alpha)
        self.surf = pygame.Surface((0, 0))
        self.surf.set_alpha(gp_alpha)
        self.rectX = x
        self.rectY = y
        self.rect = Rect(x, y + 18, 36, 18)
# Player2 finish point class
class finish2(Entity):
    def __init__(self, x, y):
        Entity.__init__(self)
        self.image = pygame.image.load(os.path.join('Assets', 'p2-endflag.png')).convert_alpha()
        self.image.set_alpha(gp_alpha)
        self.surf = pygame.Surface((0, 0))
        self.surf.set_alpha(gp_alpha)
        self.rectX = x
        self.rectY = y
        self.rect = Rect(x, y + 18, 36, 18)

entities = pygame.sprite.Group()
allGameplay = []
platforms = []
walls = []
blocks = []
halfplats = []
jumppads = []
spikeups = []
spikedowns = []
spikes = []
smallcoins = []
bigcoins = []
finish1s = []
finish2s = []

# --- Detail/deco info ---
# Background
bg_img = pygame.image.load(os.path.join('Assets', 'background.png')).convert_alpha()
bg_img = pygame.transform.scale(bg_img, (720, 720))
bg_scroll = 0
bg_alpha = 255

# Side walls
walls_img = pygame.image.load(os.path.join('Assets', 'side-walls.png')).convert_alpha()
walls_img = pygame.transform.scale(walls_img, (960, 720))
walls_scroll = 0

# --- Level generation ---
# With thanks to https://www.programiz.com/python-programming/examples/read-line-by-line

# Read level info from file and create a list containing each row
with open("level1.txt") as f:
    level1 = f.readlines()

# Generate the level using the list
x = 84   # number of pixels from left side of screen
y = 0 - (len(level1) * 36) + 720   # starting height
for row in level1:
    for col in row:
        if col == "P":
            PL = platform(x, y)
            platforms.append(PL)   # add new platform information to platforms list
            allGameplay.append(PL)
            entities.add(PL)   # add new platform to sprite group
        if col == "W":
            WL = wall(x, y)
            walls.append(WL)   # add new wall information to walls list
            allGameplay.append(WL)
            entities.add(WL)   # add new wall to sprite group 
        if col == "B":
            BL = block(x, y)
            blocks.append(BL)   # add new block information to blocks list
            allGameplay.append(BL)
            entities.add(BL)   # add new block to sprite group
        if col == "H":
            HPL = halfplat(x, y)
            halfplats.append(HPL)   # add new half-platform information to halfplats list
            allGameplay.append(HPL)
            entities.add(HPL)   # add new halfplat to sprite group
        if col == "J":
            JP = jumppad(x, y)
            jumppads.append(JP)   # add new jump-pad information to jumppads list
            allGameplay.append(JP)
            entities.add(JP)   # add new jump-pad to sprite group
        if col == "^":
            SPU = spikeup(x, y)
            spikeups.append(SPU)   # add new up-facing spike information to spikeups list
            spikes.append(SPU)
            allGameplay.append(SPU)
            entities.add(SPU)   # add new up-facing spike to sprite group
        if col == "V":
            SPD = spikedown(x, y)
            spikedowns.append(SPD)   # add new down-facing spike information to spikedowns list
            spikes.append(SPD)
            allGameplay.append(SPD)
            entities.add(SPD)   # add new down-facing spike to sprite group  
        if col == "o":
            SC = smallcoin(x, y)
            smallcoins.append(SC)   # add new small coin information to smallcoins list
            allGameplay.append(SC)  
            entities.add(SC)   # add new small coin to sprite group    
        if col == "*":
            BC = bigcoin(x, y)
            bigcoins.append(BC)   # add new big coin information to bigcoins list
            allGameplay.append(BC)  
            entities.add(BC)   # add new big coin to sprite group  
        if col == "1":
            F1 = finish1(x, y)
            finish1s.append(F1)   # add new Player1 finish point information to finish1s list
            allGameplay.append(F1)
            entities.add(F1)   # add new Player1 finish point to sprite group
        if col == "2":
            F2 = finish2(x, y)
            finish2s.append(F2)  # add new Player2 finish point information to finish2s list
            allGameplay.append(F2)
            entities.add(F2)   # add new Player2 finish point to sprite group
        x += 36
    y += 36
    x = 84
scrolled = 0

P1 = Player1()
P1.isFinished = True
P2 = Player2()
P2.isFinished = True

playersFinished = 0

players = pygame.sprite.Group()
if p1_blitHitbox == True:
    players.add(P1)
if p2_blitHitbox == True:
    players.add(P2)


# --- Cutscene animations ---
# Cutscene variables
cs_white1 = pygame.image.load(os.path.join('Assets', 'cs_white1.png')).convert_alpha()
cs_white2 = pygame.image.load(os.path.join('Assets', 'cs_white2.png')).convert_alpha()
cs_whiteIMG = cs_white1
cs_whiteSCALE = 720
cs_whiteIMG = pygame.transform.scale(cs_whiteIMG, (36, cs_whiteSCALE))
cs_white_blit = False
cs_player_blit = False
cs_whiteY = 720
title_alpha = 255

# Cutscene 1 (game start)
cutscene1_end = False
def cutscene1():
    global inCutscene
    global cs_currentFrame
    global bg_alpha
    global gp_alpha
    global inGame
    global allowScroll
    global cs_white_blit
    global cs_whiteY
    global cs_whiteSCALE
    global cs_whiteIMG
    global cs_player_blit
    global cs_whiteX1
    global cs_whiteX2
    global inMenu
    global cs_white_alpha
    global cutscene1_end
    global p1_controls
    global p2_controls
    allowScroll = True

    if inCutscene == True:
        cs_currentFrame = totalFrames - cs_startFrame   # gets current frame of cutscene animation
        cs_whiteX1 = 228
        cs_whiteX2 = 698
        # Animate cutscene
        if cs_currentFrame < 17:
            bg_alpha -= 15
        if cs_currentFrame == 17:
            inMenu = False
        if 16 < cs_currentFrame < 29:
            cs_white_blit = True
            cs_whiteY -= 60
        if 38 < cs_currentFrame < 47:
            cs_whiteY += 46
            cs_whiteSCALE -= 56
        if 46 < cs_currentFrame < 57:
            cs_whiteY += 19
            cs_whiteSCALE -= 23
        if cs_currentFrame == 57:
            cs_whiteIMG = cs_white2
            cs_whiteSCALE = 36
            cs_whiteY = 544
        if cs_currentFrame == 65:
            cs_white_blit = False
            cs_player_blit = True
        if cs_currentFrame == 67:
            cs_white_blit = True
            cs_player_blit = False
        if cs_currentFrame == 71:
            cs_white_blit = False
            cs_player_blit = True
        if cs_currentFrame == 77:
            cs_white_blit = True
            cs_player_blit = False
        if cs_currentFrame == 85:
            cs_white_blit = False
            cs_player_blit = True
        if cs_currentFrame == 92:
            cs_white_blit = True
            cs_player_blit = False
        if 92 < cs_currentFrame < 110:
            cs_white_blit = False
            cs_player_blit = True
            allowScroll = False
            gp_alpha += 15
            bg_alpha += 15   
        # Finish cutscene, begin level
        if cs_currentFrame == 110:
            cs_player_blit = False
            inGame = True
            inCutscene = False
            cutscene1_end = True
            P1.isFinished = False
            P2.isFinished = False
        bg_img.set_alpha(bg_alpha)
        walls_img.set_alpha(bg_alpha)
        p1_controls.set_alpha(gp_alpha)
        p2_controls.set_alpha(gp_alpha)
        for i in allGameplay:
            i.surf.set_alpha(gp_alpha)
        for i in spikeups:
            i.image.set_alpha(gp_alpha)
        for i in spikedowns:
            i.image.set_alpha(gp_alpha)
        for i in finish1s:
            i.image.set_alpha(gp_alpha)
        for i in finish2s:
            i.image.set_alpha(gp_alpha)

        cs_whiteIMG = pygame.transform.scale(cs_whiteIMG, (36, cs_whiteSCALE))

# Cutscene 2 (game end)
cs_white_alpha = 0
cutscene2_end = False
def cutscene2():
    global gp_alpha
    global cs_white_blit
    global cs_whiteX1
    global cs_whiteX2
    global cs_whiteY
    global inGame
    global bg_alpha
    global cs_white_alpha
    global cutscene2_end
    global cutscene3_startFrame
    global inCutscene

    if playersFinished == 1:
        if bg_alpha > 120:
            bg_alpha -= 10
        bg_img.set_alpha(bg_alpha)

    if playersFinished == 2:
        if bg_alpha > 0:
            bg_alpha -= 10
        bg_img.set_alpha(bg_alpha)

        if gp_alpha > 0:
            gp_alpha -= 15
        if cs_white_alpha < 255:
            cs_white_alpha += 15
        
        for i in allGameplay:
            i.surf.set_alpha(gp_alpha)
        for i in spikeups:
            i.image.set_alpha(gp_alpha)
        for i in spikedowns:
            i.image.set_alpha(gp_alpha)
        for i in finish1s:
            i.image.set_alpha(gp_alpha)
        for i in finish2s:
            i.image.set_alpha(gp_alpha)

        p1_texture_bottom.set_alpha(gp_alpha)
        p1_texture_top.set_alpha(gp_alpha)
        p1_facing.set_alpha(gp_alpha)
        p2_texture_bottom.set_alpha(gp_alpha)
        p2_texture_top.set_alpha(gp_alpha)
        p2_facing.set_alpha(gp_alpha)
        walls_img.set_alpha(gp_alpha)

        cs_whiteIMG.set_alpha(cs_white_alpha)
        cs_whiteX1 = p1_blitX
        cs_whiteX2 = p2_blitX
        if p1_isAlive == True:
            cs_whiteY = p1_blitY
        else:
            cs_whiteY = p2_blitY
        cs_white_blit = True

        if gp_alpha == 0:
            inGame = False
            inCutscene = True
            cutscene2_end = True
            cutscene3_startFrame = totalFrames

# Cutscene 3 (fade to endscreen)
cutscene3_end = False
cutscene3_fade = False
def cutscene3():
    global cs_whiteInc
    global cs_whiteY
    global bg_alpha
    global cutscene3_end
    global cutscene3_fade
    global inCutscene
    if totalFrames == (cutscene3_startFrame + 30):
        cs_whiteInc = 0
    if totalFrames > (cutscene3_startFrame + 30):
        if cs_whiteY >= -36:
            cs_whiteInc += 1
            cs_whiteY -= cs_whiteInc
    if totalFrames == (cutscene3_startFrame + 80):
        cutscene3_fade = True
    if totalFrames > (cutscene3_startFrame + 80):
        if bg_alpha < 255:
            bg_alpha += 10
        if bg_alpha == 255:
            cutscene3_end = True
            inCutscene = False
        bg_img.set_alpha(bg_alpha)
        walls_img.set_alpha(bg_alpha)


# Endscreen
end_text_y = -800
end_text_inc = 12
thankyou_y = 1200
def endScreen():
    # Calculate final score
    global score
    global gameover_img
    score = points * (1 + p1_lives + p2_lives)

    # Animate: Game Over / Tower Cleared text
    global end_text
    global end_text_y
    global end_text_inc
    global thankyou_y
    global thankyou_img
    gameover_img = pygame.image.load(os.path.join('Assets', 'game-over.png')).convert_alpha()
    towerclear_img = pygame.image.load(os.path.join('Assets', 'tower-clear.png')).convert_alpha()
    thankyou_img = pygame.image.load(os.path.join('Assets', 'thanks-for-playing.png')).convert_alpha()
    if (p1_lives + p2_lives) <= 0:
        end_text = gameover_img
    else:
        end_text = towerclear_img
    end_text = pygame.transform.scale(end_text, (960, 720))
    thankyou_img = pygame.transform.scale_by(thankyou_img, 4)
    if totalFrames > (cutscene3_startFrame + 120) and (totalFrames % 3) == 0:
        if end_text_inc > 0:
            end_text_inc -= 1
        else:
            getScore()
    end_text_y += end_text_inc
    thankyou_y -= end_text_inc

displayScore = False
def getScore():
    global font
    global scoreText
    global displayScore
    global labelText
    global labelRect
    global scoreText_x
    global scoreRect
    global fullRect
    # Create text for "SCORE:" label
    labelText = font.render('SCORE: ', False, WHITE, None)
    labelText = pygame.transform.scale_by(labelText, 3)
    labelRect = labelText.get_rect()
    labelRect.left = 0
    # Create text for score
    scoreText = font.render(str(score), False, WHITE, None)
    scoreText = pygame.transform.scale_by(scoreText, 3)
    scoreRect = scoreText.get_rect()
    scoreRect.left = labelRect.right
    # Align text to center screen
    fullRect = labelRect.union(scoreRect)
    fullRect.centerx = 480
    labelRect.left = fullRect.left
    scoreText_x = labelRect.right
    # Display text
    displayScore = True


# Title screen
title_img_y = -640
title_img_inc = 12
tellPressSpace = False
def titleAnim():
    global title_img
    global title_img_inc
    global title_img_y
    global tellPressSpace
    global pressSpaceText
    global pressSpaceRect
    title_img = pygame.image.load(os.path.join('Assets', 'game-logo.png')).convert_alpha()
    title_img = pygame.transform.scale(title_img, (960, 720))
    if totalFrames > 40 and (totalFrames % 3) == 0:
        if title_img_inc > 0:
            title_img_inc -= 1
        else:
            if totalFrames % 30 > 15:
                tellPressSpace = True
            else:
                tellPressSpace = False
    title_img_y += title_img_inc

    pressSpaceText = font.render('PRESS SPACE', False, WHITE, None)
    pressSpaceText = pygame.transform.scale_by(pressSpaceText, 2)
    pressSpaceRect = pressSpaceText.get_rect()
    pressSpaceRect.centerx = 480
    pressSpaceRect.top = 500

# --- Game loop ---
running = True
while running:
    # Update frame counter
    currentFrame += 1
    if currentFrame > 30:
        currentFrame = 1

    screen.fill(BLACK)

    for event in pygame.event.get():
        # Detect quit game
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    
        # Detect jump keypress
        if event.type == pygame.KEYDOWN:
            if inGame == True:
                if event.key == pygame.K_w:
                    P1.jump()
                    p1_displayControls = False
                if event.key == pygame.K_i:
                    P2.jump()     
                    p2_displayControls = False           
            if inGame == False and cutscene3_end == False:
                if inCutscene == False:
                    if event.key == pygame.K_SPACE:
                        cs_startFrame = totalFrames
                        inCutscene = True

    if cutscene1_end == False:
        cutscene1()
    if cutscene2_end == False:
        cutscene2()
    if cutscene2_end == True and cutscene3_end == False:
        cutscene3()
    if cutscene3_fade == True:
        endScreen()

    # Blit background image
    if inMenu == True or cutscene3_fade == True:
        bgScroll()
    screen.blit(bg_img, (120, bg_scroll))
    screen.blit(bg_img, (120, bg_scroll - 720))
    # Blit title screen
    if inMenu == True and inCutscene == False:
        titleAnim()
        screen.blit(title_img, (0, title_img_y))
        if tellPressSpace == True:
            screen.blit(pressSpaceText, (pressSpaceRect))
    # Blit endscreen text
    if end_text_y > -720:
        screen.blit(end_text, (0, end_text_y))
        screen.blit(thankyou_img, (0, thankyou_y))
    # Blit final score
    if displayScore == True:
        screen.blit(labelText, (labelRect.left, 400))
        screen.blit(scoreText, (scoreText_x, 400))

    # If in game, update gameplay and players
    if inGame == True:
        if p1_isAlive == True:
            P1.move()
            P1.duck()
            P1.collisions()
            P1.pointUpdate()
            P1.damage()
        else:
            P1.pos.y = P2.pos.y
            p1_centerY = p2_centerY

        if p2_isAlive == True:
            P2.move()
            P2.duck()
            P2.collisions()
            P2.pointUpdate()
            P2.damage()
        else:
            P2.pos.y = P1.pos.y
            p2_centerY = p1_centerY

        gpScroll()

        if p2_isAlive == True:
            P2.blit()
        if p1_isAlive == True:
            P1.blit()
        for entity in players:
            screen.blit(entity.image, entity.rect)

    # Blit all gameplay elements
    for i in allGameplay:
        screen.blit(i.surf, i.rect)
    for i in spikeups:
        screen.blit(i.image, (i.rectX, i.rectY))
    for i in spikedowns:
        screen.blit(i.image, (i.rectX, i.rectY))
    for i in finish1s:
        screen.blit(i.image, (i.rectX, i.rectY))
    for i in finish2s:
        screen.blit(i.image, (i.rectX, i.rectY))
    
    # Blit player control guide
    if p1_displayControls == True:
        screen.blit(p1_controls, (0, 50))
    if p2_displayControls == True:
        screen.blit(p2_controls, (0, 50))

    # Blit side walls image
    screen.blit(walls_img, (0, walls_scroll))
    screen.blit(walls_img, (0, walls_scroll - 720))

    # Blit hearts for lives counter
    if inGame == True:
        if p1_lives >= 1:
            screen.blit(p1_heart, (16, 2))
        if p1_lives >= 2:
            screen.blit(p1_heart, (16, 58))
        if p1_lives >= 3:
            screen.blit(p1_heart, (16, 114))

        if p2_lives >= 1:
            screen.blit(p2_heart, (890, 2))
        if p2_lives >= 2:
            screen.blit(p2_heart, (890, 58))
        if p2_lives >= 3:
            screen.blit(p2_heart, (890, 114))
 
    # Blitting for cutscene1
    if cs_white_blit == True:
        if p1_isAlive == True:
            screen.blit(cs_whiteIMG, (cs_whiteX1, cs_whiteY))
        if p2_isAlive == True:
            screen.blit(cs_whiteIMG, (cs_whiteX2, cs_whiteY))
    if cs_player_blit == True:
        screen.blit(p1_texture_bottom, (228, cs_whiteY))
        screen.blit(p1_texture_top, (228, cs_whiteY))
        screen.blit(p1_facing, (228, cs_whiteY))
        screen.blit(p2_texture_bottom, (698, cs_whiteY))
        screen.blit(p2_texture_top, (698, cs_whiteY))
        screen.blit(p2_facing, (698, cs_whiteY))

    # Refresh screen
    pygame.display.update()
    FramePerSec.tick(FPS)
    totalFrames += 1

pygame.quit()